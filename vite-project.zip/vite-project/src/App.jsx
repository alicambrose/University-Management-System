import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Login from './Login';
import StudentDetails from './components/StudentDetails';
import TopNavBar from './TopNavBar';
import Home from './Home';
import VisitorProfile from './components/VisitorProfile';
import StudentInquiries from './components/StudentInquiries';
import StudentCourses from './components/StudentCourses';

const MainLayout = ({ children }) => {
  return (
    <div className="app-container">
      <TopNavBar />
      <div className="main-content-wrapper">
        {children}
      </div>
    </div>
  );
};

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/home" element={
          <MainLayout>
            <Home />
          </MainLayout>
        } />
        <Route path="/student-details" element={
          <MainLayout>
            <StudentDetails />
          </MainLayout>
        } />
        <Route path="/visitor-details" element={
          <MainLayout>
            <VisitorProfile />
          </MainLayout>
        } />
        <Route path="/student-inquiries" element={
          <MainLayout>
            <StudentInquiries />
          </MainLayout>
        } />
        
        <Route path="/student-courses" element={
          <MainLayout>
            <StudentCourses />
          </MainLayout>
        } />
      </Routes>
    </Router>
  );
};

export default App;