import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Dashboard</h1>
      {/* Add your home page content here */}
    </div>
  );
};

export default Home;