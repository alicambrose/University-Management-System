import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';
import './VisitorProfile.css';
import TopNavBar from '../TopNavBar';

const VisitorProfile = () => {
  // State for tracking which sections are in edit mode
  const [editingSections, setEditingSections] = useState({
    'visitor-details': false,
    'applicant': false,
    'description': false,
  });

  // State for active section
  const [activeSection, setActiveSection] = useState('visitor-details');
  
  // State for all form data
  const [formData, setFormData] = useState({
    // Visitor Details
    firstName: '',
    lastName: '',
    gender: 'Male',
    overseas: '',
    email: '',
    mobile: '',
    city: '',
    country: '',
    alumni: '',
    internationalStudent: '',
    admissionFormIssued: '',
    onlineVisitor: '',
    ilm: '',
    ntsSpecialTest: '',
    dae: '',
    pwwb: '',
    callByAgent: '',
    vpn: '',
    certificateStudent: '',
    primaryProgram: '',
    secondaryProgram: '',
    semester: '',
    hearingSource: '',
    sourceOfInformation: '',
    visitorType: '',
    latestQualification: '',
    schoolCollegeUniversity: '',
    webVpn: '',
    handicapCondition: 'No',
    learningSupportRequest: '',
    financialAssistanceRequest: '',
    technicalAssistance: '',
    supportRequiredFrom: '',
    gettingFinancial: '',
    natureOfFinancial: '',
    
    // Applicant
    referenceId: '',
    
    // Description
    description: ''
  });

  // Handle section navigation
  const handleNavClick = (sectionId) => {
    setActiveSection(sectionId);
  };

  // Toggle edit mode for a section
  const toggleEdit = (sectionId) => {
    setEditingSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  // Save section data
  const saveSection = (sectionId) => {
    console.log(`Saving data for ${sectionId}`, formData);
    setEditingSections(prev => ({
      ...prev,
      [sectionId]: false
    }));
  };

  // Handle input changes
  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Save all edited sections
  const saveAll = () => {
    Object.keys(editingSections).forEach(sectionId => {
      if (editingSections[sectionId]) {
        saveSection(sectionId);
      }
    });
  };

  return (
    <div className="app-container">
      {/* Vertical Sidebar Navigation */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="student-photo-container">
            <div className="photo-wrapper">
              <img className="student-photo" src="https://banner2.cleanpng.com/20181110/srt/kisspng-computer-icons-login-scalable-vector-graphics-emai-1713924340552.webp" alt="Student" />
              <div className="photo-actions">
                <button className="btn btn-sm btn-light"><i className="fas fa-camera"></i></button>
                <button className="btn btn-sm btn-light"><i className="fas fa-upload"></i></button>
              </div>
            </div>
          </div>
          <div className="visitor-details">
            <h5 className="visitor-name">Test Visitor</h5>
          </div>
        </div>
        <nav className="sidebar-nav">
          <ul>
            <li 
              className={activeSection === 'visitor-details' ? 'active' : ''} 
              onClick={() => handleNavClick('visitor-details')}
            >
              <i className="fas fa-user-circle"></i>
              <span>Visitor Details</span>
            </li>
            <li 
              className={activeSection === 'applicant' ? 'active' : ''} 
              onClick={() => handleNavClick('applicant')}
            >
              <i className="fas fa-graduation-cap"></i>
              <span>Applicant</span>
            </li>
          </ul>
        </nav>
        <div className="sidebar-footer">
          <button className="btn btn-danger btn-sm">
            <i className="fas fa-trash-alt me-1"></i> Delete
          </button>
        </div>
      </div>
      
      {/* Main Content Area */}
      <div className="main-content">
        {/* Top Action Bar */}
        <div className="top-bar shadow-sm">
          <div className="container-fluid">
            <div className="d-flex align-items-center">
              <button 
                className="btn-action btn-save"
                onClick={saveAll}
                disabled={!Object.values(editingSections).some(Boolean)}
              >
                <i className="fas fa-save me-2"></i>Save
              </button>
              {/* Other action buttons... */}
            </div>
          </div>
        </div>
        
        {/* Content Sections */}
        <div className="content-sections">
          {/* Visitor Details Section */}
        <section 
            id="visitor-details" 
            className={`content-section ${activeSection === 'visitor-details' ? 'active' : ''} ${editingSections['visitor-details'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-user-circle me-2"></i>Visitor Details</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('visitor-details')}
              >
                {editingSections['visitor-details'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['visitor-details'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('visitor-details')}
                >
                  Save Section
                </button>
              )}
            </div>
            <div className="form-grid">
              {/* First Name */}
              <div className="form-group">
                <label className="field-label">First Name:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.firstName}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.firstName}
                    onChange={(e) => handleInputChange('firstName', e.target.value)}
                  />
                )}
              </div>
              
              {/* Last Name */}
              <div className="form-group">
                <label className="field-label">Last Name:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.lastName}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.lastName}
                    onChange={(e) => handleInputChange('lastName', e.target.value)}
                  />
                )}
              </div>
              
              {/* Gender */}
              <div className="form-group">
                <label className="field-label">Gender:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.gender}</div>
                ) : (
                  <select 
                    className="field-input form-control"
                    value={formData.gender}
                    onChange={(e) => handleInputChange('gender', e.target.value)}
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                )}
              </div>
              
              {/* Overseas */}
              <div className="form-group">
                <label className="field-label">Overseas:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.overseas}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.overseas}
                    onChange={(e) => handleInputChange('overseas', e.target.value)}
                  />
                )}
              </div>
                
              {/* Continue with all other fields in the same pattern */}
              <div className="form-group">
                <label className="field-label">Email:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.email}</div>
                ) : (
                  <input 
                    type="email" 
                    className="field-input form-control" 
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                  />
                )}
              </div>
              
              {/* Mobile */}
              <div className="form-group">
                <label className="field-label">Mobile:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.mobile}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.mobile}
                    onChange={(e) => handleInputChange('mobile', e.target.value)}
                  />
                )}
              </div>
                <div className="form-group">
                <label className="field-label">City:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.city}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Country:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.country}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.country}
                    onChange={(e) => handleInputChange('country', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Alumni:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.alumni}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.alumni}
                    onChange={(e) => handleInputChange('alumni', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">International Student:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.internationalStudent}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.internationalStudent}
                    onChange={(e) => handleInputChange('internationalStudent', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Admission Form Issued:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.admissionFormIssued}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.admissionFormIssued}
                    onChange={(e) => handleInputChange('admissionFormIssued', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Online Visitor:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.onlineVisitor}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.onlineVisitor}
                    onChange={(e) => handleInputChange('onlineVisitor', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">ILM:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.ilm}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.ilm}
                    onChange={(e) => handleInputChange('ilm', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">NTS/Special Test:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.specialTest}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.specialTest}
                    onChange={(e) => handleInputChange('specialTest', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">DAE:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.dae}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.dae}
                    onChange={(e) => handleInputChange('dae', e.target.value)}
                  />
                )}
              </div><div className="form-group">
                <label className="field-label">PWWB:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.pwwb}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.pwwb}
                    onChange={(e) => handleInputChange('pwwb', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Call By Agent:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.callByAgent}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.callByAgent}
                    onChange={(e) => handleInputChange('callByAgent', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">VPN:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.vpn}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.vpn}
                    onChange={(e) => handleInputChange('vpn', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Certificate Student:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.certificateStudent}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.certificateStudent}
                    onChange={(e) => handleInputChange('certificateStudent', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Primary Program Of:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.primaryProgramOf}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.primaryProgramOf}
                    onChange={(e) => handleInputChange('primaryProgramOf', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">secondary program of:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.secondaryProgramOf}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.secondaryProgramOf}
                    onChange={(e) => handleInputChange('secondaryProgramOf', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Semester:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.semester}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.semester}
                    onChange={(e) => handleInputChange('semester', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Hearing Source:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.hearingSource}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.hearingSource}
                    onChange={(e) => handleInputChange('hearingSource', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Source of Information:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.sourceOfInformation}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.sourceOfInformation}
                    onChange={(e) => handleInputChange('sourceOfInformation', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Visitor Type:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.visitorType}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.visitorType}
                    onChange={(e) => handleInputChange('visitorType', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Latest Qualification:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.latestQualification}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.latestQualification}
                    onChange={(e) => handleInputChange('latestQualification', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">School/College/University:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.schoolCollegeUniversity}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.schoolCollegeUniversity}
                    onChange={(e) => handleInputChange('schoolCollegeUniversity', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Web VPN:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.webVpn}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.webVpn}
                    onChange={(e) => handleInputChange('webVpn', e.target.value)}
                  />
                )}
              </div>
              {/* Continue this pattern for all remaining fields */}
              {/* Example for Handicap Condition */}
              <div className="form-group">
                <label className="field-label">Handicap Condition:</label>
                {!editingSections['visitor-details'] ? (
                  <div className="field-value">{formData.handicapCondition}</div>
                ) : (
                  <select 
                    className="field-input form-control"
                    value={formData.handicapCondition}
                    onChange={(e) => handleInputChange('handicapCondition', e.target.value)}
                  >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                  </select>
                )}
              </div>
              
              {/* Add all other fields following the same pattern */}
              
            </div>
             <section 
            id="description" 
            className={`content-section ${activeSection === 'description' ? 'active' : ''} ${editingSections['description'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-money-bill-wave me-2"></i>Description</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('description')}
              >
                {editingSections['description'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['description'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('description')}
                >
                  Save Section
                </button>
              )}
            </div> 
            <div className="form-grid">
              <div className="form-group">
                <label className="field-label">Description:</label>
                {!editingSections['description'] ? (
                  <div className="field-value">{formData.description}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                  />
                )}
              </div>
            </div>
          </section>
          </section>

          {/* Applicant Section */}
          <section 
            id="applicant" 
            className={`content-section ${activeSection === 'applicant' ? 'active' : ''} ${editingSections['applicant'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-graduation-cap me-2"></i>Applicant</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('applicant')}
              >
                {editingSections['applicant'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['applicant'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('applicant')}
                >
                  Save Section
                </button>
              )}
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label className="field-label">Reference ID:</label>
                {!editingSections['applicant'] ? (
                  <div className="field-value">{formData.referenceId}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.referenceId}
                    onChange={(e) => handleInputChange('referenceId', e.target.value)}
                  />
                )}
              </div>
            </div>  
             <div className="section-header">
              <h4><i className="fas fa-money-bill-wave me-2"></i>Description</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('description')}
              >
                {editingSections['description'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['description'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('description')}
                >
                  Save Section
                </button>
              )}
            </div> 
            <div className="form-grid">
              <div className="form-group">
                <label className="field-label">Description:</label>
                {!editingSections['description'] ? (
                  <div className="field-value">{formData.description}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                  />
                )}
              </div>
            </div>
          </section> 
        </div>
      </div>
    </div>
  );
};

export default VisitorProfile;