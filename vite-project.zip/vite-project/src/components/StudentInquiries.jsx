import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';
import './StudentInquiries.css';
import TopNavBar from '../TopNavBar';

const StudentInquiries = () => {
  // State for tracking which sections are in edit mode
  const [editingSections, setEditingSections] = useState({
    'student-inquiries': false,
    'requested-courses': false,
    'description': false
  });

  // State for active section
  const [activeSection, setActiveSection] = useState('student-inquiries');
  
  // State for form data
  const [formData, setFormData] = useState({
    student: '',
    inquiryType: '',
    semester: '',
    inquiryTitle: '',
    showAllBatches: '',
    showFlow: '',
    inquiryId: '',
    program: '',
    batch: '',
    cgpa: '',
    inquiryCategory: '',
    showAllFaculty: '',
    update: '',
    description: ''
  });

  // State for tables
  const [inquiryTableData, setInquiryTableData] = useState([
    { id: 1, course: "Mathematics", requestType: "Add", batchCourse: "BSCS-2023", creditHours: 3 },
    { id: 2, course: "Physics", requestType: "Drop", batchCourse: "BSCS-2023", creditHours: 4 }
  ]);

  const [requestedCoursesData, setRequestedCoursesData] = useState([]);
  const [editingStatusId, setEditingStatusId] = useState(null);

  // Move row from inquiry table to requested courses table
  const moveToRequestedCourses = (rowData) => {
    setInquiryTableData(prev => prev.filter(item => item.id !== rowData.id));
    setRequestedCoursesData(prev => [
      ...prev,
      {
        ...rowData,
        facultyCourse: `${rowData.course} Faculty`,
        status: "Pending"
      }
    ]);
  };

  // Toggle edit mode for status
  const toggleEditStatus = (id) => {
    setEditingStatusId(editingStatusId === id ? null : id);
  };

  // Update status
  const updateStatus = (id, newStatus) => {
    setRequestedCoursesData(prev =>
      prev.map(item =>
        item.id === id ? { ...item, status: newStatus } : item
      )
    );
    setEditingStatusId(null);
  };

  // Handle section navigation
  const handleNavClick = (sectionId) => {
    setActiveSection(sectionId);
  };

  // Toggle edit mode for a section
  const toggleEdit = (sectionId) => {
    setEditingSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  // Save section data
  const saveSection = (sectionId) => {
    console.log(`Saving data for ${sectionId}`, formData);
    setEditingSections(prev => ({
      ...prev,
      [sectionId]: false
    }));
  };

  // Handle input changes
  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Save all edited sections
  const saveAll = () => {
    Object.keys(editingSections).forEach(sectionId => {
      if (editingSections[sectionId]) {
        saveSection(sectionId);
      }
    });
  };

  return (
    <div className="app-container">
      {/* Vertical Sidebar Navigation */}
      <div className="sidebar">
        <div className="sidebar-header"></div>
        <nav className="sidebar-nav">
          <ul>
            <li 
              className={activeSection === 'student-inquiries' ? 'active' : ''} 
              onClick={() => handleNavClick('student-inquiries')}
            >
              <i className="fas fa-user-circle"></i>
              <span>Student Inquiry Details</span>
            </li>
            <li 
              className={activeSection === 'requested-courses' ? 'active' : ''} 
              onClick={() => handleNavClick('requested-courses')}
            >
              <i className="fas fa-book"></i>
              <span>Requested Courses</span>
            </li>
          </ul>
        </nav>
        <div className="sidebar-footer">
          <button className="btn btn-danger btn-sm">
            <i className="fas fa-trash-alt me-1"></i> Delete
          </button>
        </div>
      </div>
      
      {/* Main Content Area */}
      <div className="main-content">
        {/* Top Action Bar */}
        <div className="top-bar shadow-sm">
          <div className="container-fluid">
            <div className="d-flex align-items-center">
              <button 
                className="btn-action btn-save"
                onClick={saveAll}
                disabled={!Object.values(editingSections).some(Boolean)}
              >
                <i className="fas fa-save me-2"></i>Save
              </button>
              {/* Other action buttons... */}
            </div>
          </div>
        </div>
        
        {/* Content Sections */}
        <div className="content-sections">
          {/* Student Inquiries Section */}
          <section 
            id="student-inquiries" 
            className={`content-section ${activeSection === 'student-inquiries' ? 'active' : ''} ${editingSections['student-inquiries'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-user-circle me-2"></i>New Student Inquiry</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('student-inquiries')}
              >
                {editingSections['student-inquiries'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['student-inquiries'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('student-inquiries')}
                >
                  Save Section
                </button>
              )}
            </div>
            <div className="form-grid">
              {/* Student */}
              <div className="form-group">
                <label className="field-label">Student:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.student}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.student}
                    onChange={(e) => handleInputChange('student', e.target.value)}
                  />
                )}
              </div>
              
              {/* Inquiry Type */}
              <div className="form-group">
                <label className="field-label">Inquiry Type:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.inquiryType}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.inquiryType}
                    onChange={(e) => handleInputChange('inquiryType', e.target.value)}
                  />
                )}
              </div>
              
              {/* Semester */}
              <div className="form-group">
                <label className="field-label">Semester:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.semester}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.semester}
                    onChange={(e) => handleInputChange('semester', e.target.value)}
                  />
                )}
              </div>
              
              {/* Continue with all other fields in the same pattern */}
              <div className="form-group">
                <label className="field-label">Inquiry Title:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.inquiryTitle}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.inquiryTitle}
                    onChange={(e) => handleInputChange('inquiryTitle', e.target.value)}
                  />
                )}
              </div>
              
              {/* Show All Batches */}
              <div className="form-group">
                <label className="field-label">Show All Batches:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.showAllBatches}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.showAllBatches}
                    onChange={(e) => handleInputChange('showAllBatches', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Show Flow:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.showFlow}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.showFlow}
                    onChange={(e) => handleInputChange('showFlow', e.target.value)}
                  />
                )}
              </div>
                <div className="form-group">
                <label className="field-label">Inquiry ID:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.inquiryId}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.inquiryId}
                    onChange={(e) => handleInputChange('inquiryId', e.target.value)}
                  />
                )}
              </div>
                <div className="form-group">
                <label className="field-label">Program:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.program}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.program}
                    onChange={(e) => handleInputChange('program', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Batch:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.batch}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.batch}
                    onChange={(e) => handleInputChange('batch', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">CGPA:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.cgpa}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.cgpa}
                    onChange={(e) => handleInputChange('cgpa', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Inuiry Category:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.inquiryCategory}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.inquiryCategory}
                    onChange={(e) => handleInputChange('inquiryCategory', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Show All Faculty:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.showAllFaculty}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.showAllFaculty}
                    onChange={(e) => handleInputChange('showAllFaculty', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Update:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.update}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.update}
                    onChange={(e) => handleInputChange('update', e.target.value)}
                  />
                )}
              </div>          
              {/* Add all other fields following the same pattern */}
            </div>
            
            {/* Description Section */}
            <div className="section-header">
              <h4><i className="fas fa-file-alt me-2"></i>Description</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('description')}
              >
                {editingSections['description'] ? 'Cancel' : 'Edit'}
              </button>
              {/* {editingSections['description'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('description')}
                >
                  Save Section
                </button>
              )} */}
            </div>
            <div className="form-group">
                <label className="field-label">Write:</label>
                {!editingSections['student-inquiries'] ? (
                  <div className="field-value">{formData.showAllBatches}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.showAllBatches}
                    onChange={(e) => handleInputChange('showAllBatches', e.target.value)}
                  />
                )}
              </div>
              
            
            {/* Inquiry Table */}
            <table className="inquiry-table">
              <thead>
                <tr>
                  <th>Course</th>
                  <th>Request Type</th>
                  <th>Batch Course</th>
                  <th>Credit Hours</th>
                </tr>
              </thead>
              <tbody>
                {inquiryTableData.length > 0 ? (
                  inquiryTableData.map(row => (
                    <tr 
                      key={row.id} 
                      onClick={() => moveToRequestedCourses(row)}
                      style={{ cursor: 'pointer' }}
                      className="table-row-hover"
                    >
                      <td>{row.course}</td>
                      <td>{row.requestType}</td>
                      <td>{row.batchCourse}</td>
                      <td>{row.creditHours}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" className="empty-table-message">
                      No course requests available
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </section>
          
          {/* Requested Courses Section */}
          <section 
            id="requested-courses" 
            className={`content-section ${activeSection === 'requested-courses' ? 'active' : ''} ${editingSections['requested-courses'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-book me-2"></i>Requested Courses</h4>
            </div>
            
            <table className="inquiry-table">
              <thead>
                <tr>
                  <th>Course</th>
                  <th>Batch Course</th>
                  <th>Faculty Course</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {requestedCoursesData.length > 0 ? (
                  requestedCoursesData.map(row => (
                    <tr key={row.id}>
                      <td>{row.course}</td>
                      <td>{row.batchCourse}</td>
                      <td>{row.facultyCourse}</td>
                      <td>
                        {editingStatusId === row.id ? (
                          <select
                            className="form-select form-select-sm"
                            value={row.status}
                            onChange={(e) => updateStatus(row.id, e.target.value)}
                          >
                            <option value="Pending">Pending</option>
                            <option value="Approve">Approve</option>
                            <option value="Reject">Reject</option>
                          </select>
                        ) : (
                          <span className={`badge ${
                            row.status === "Approve" ? "bg-success" :
                            row.status === "Reject" ? "bg-danger" : "bg-warning"
                          }`}>
                            {row.status}
                          </span>
                        )}
                      </td>
                      <td>
                        {editingStatusId === row.id ? (
                          <button 
                            className="btn btn-sm btn-success"
                            onClick={() => setEditingStatusId(null)}
                          >
                            Save
                          </button>
                        ) : (
                          <button 
                            className="btn btn-sm btn-primary"
                            onClick={() => toggleEditStatus(row.id)}
                          >
                            Edit
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="empty-table-message">
                      No requested courses yet. Select courses from the Student Inquiry table.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </section>
        </div>
      </div>
    </div>
  );
};

export default StudentInquiries;