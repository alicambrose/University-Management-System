// export default StudentDetails;
import React, { useState } from 'react';
import { useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';
import './StudentDetails.css';
import TopNavBar from '../TopNavBar';

const StudentDetails = () => {
  // State for tracking which sections are in edit mode
  const [editingSections, setEditingSections] = useState({
    'general-info': false,
    'program-info': false,
    'fee-info': false,
    'entry-slip': false,
    'family-info': false
  });

  // State for active section
  const [activeSection, setActiveSection] = useState('general-info');
  
  // State for all form data
  const [formData, setFormData] = useState({
    // General Info
    visitorReference: '',
    cnic: '',
    email: '',
    course: '',
    mobile: '',
    resultStatus: '',
    challanNo: '',
    umtHostelRoom: '',
    umtTransport: '',
    pwwb: '',
    refund: '',
    approvalStatus: '',
    learningSupport: '',
    bloodRelated: '',
    vpn: '',
    dob: '',
    telephone: '',
    maritalStatus: '',
    gender: 'Male',
    issuedLocation: '',
    alumni: '',
    overseas: '',
    transferredFrom: '',
    religion: '',
    nationality: '',
    referenceId: '',
    
    // Program Info
    campus: '',
    school: '',
    program: '',
    programTrack: '',
    batch: '',
    semester: '',
    applicantType: '',
    meritCriteria: '',
    
    // Fee Info
    scheduleType: '',
    firstInstallment: '',
    nextInstallment: '',
    admissionFee: '',
    challanIssued: '',
    challanIssuedDate: '',
    hostelite: '',
    libraryFee: '',
    totalFee: '',
    atp: '',
    tax: '',
    oiaFeeComments: '',
    feePerInstallment: '',
    dueDate: '',
    discount: '',
    discountPercentage: '',
    approvedBy: '',
    perCreditHour: '',
    miscellaneousFee: '',
    miscellaneousDetails: '',
    generatePayment: '',
    created: '',
    
    // Entry Slip
    entryTestAddress: '',
    testDateTime: '',
    
    // Family Info
    fatherDeceased: '',
    fatherName: '',
    fatherCnic: '',
    fatherAddress: '',
    fatherMobile: '',
    fatherDesignation: '',
    fatherOrganization: '',
    fatherOrgAddress: '',
    fatherOrgNumber: '',
    motherDeceased: '',
    motherName: '',
    motherCnic: '',
    motherAddress: '',
    motherMobile: '',
    motherDesignation: '',
    motherOrganization: '',
    motherOrgAddress: '',
    motherOrgNumber: '',
    guardianName: '',
    guardianCnic: '',
    guardianAddress: '',
    guardianMobile: '',
    guardianDesignation: '',
    guardianOrganization: '',
    guardianOrgAddress: '',
    guardianOrgNumber: '',
    relationship: ''
  });

  // Handle section navigation
  const handleNavClick = (sectionId) => {
    setActiveSection(sectionId);
  };

  // Toggle edit mode for a section
  const toggleEdit = (sectionId) => {
    setEditingSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  // Save section data
  const saveSection = (sectionId) => {
    // Here you would typically save data to an API
    console.log(`Saving data for ${sectionId}`, formData);
    
    // Exit edit mode
    setEditingSections(prev => ({
      ...prev,
      [sectionId]: false
    }));
  };

  // Handle input changes
  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Save all edited sections
  const saveAll = () => {
    Object.keys(editingSections).forEach(sectionId => {
      if (editingSections[sectionId]) {
        saveSection(sectionId);
      }
    });
  };

  return (
    <div className="app-container">
      {/* Vertical Sidebar Navigation */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="student-photo-container">
            <div className="photo-wrapper">
              <img className="student-photo" src="https://banner2.cleanpng.com/20181110/srt/kisspng-computer-icons-login-scalable-vector-graphics-emai-1713924340552.webp" alt="Student" />
              <div className="photo-actions">
                <button className="btn btn-sm btn-light"><i className="fas fa-camera"></i></button>
                <button className="btn btn-sm btn-light"><i className="fas fa-upload"></i></button>
              </div>
            </div>
          </div>
          <div className="student-info">
            <h5 className="student-name">test student</h5>
            <div className="student-id">
              <i className="fas fa-id-card me-1"></i> ID: S2020266043
            </div>
            <div className="student-status">
              <span className="badge bg-info text-dark">Applicant</span>
              <span className="badge bg-warning text-dark">Third Division</span>
            </div>
          </div>
        </div>
        <nav className="sidebar-nav">
          <ul>
            <li 
              className={activeSection === 'general-info' ? 'active' : ''} 
              onClick={() => handleNavClick('general-info')}
            >
              <i className="fas fa-user-circle"></i>
              <span>General Information</span>
            </li>
            <li 
              className={activeSection === 'program-info' ? 'active' : ''} 
              onClick={() => handleNavClick('program-info')}
            >
              <i className="fas fa-graduation-cap"></i>
              <span>Program Information</span>
            </li>
            <li 
              className={activeSection === 'fee-info' ? 'active' : ''} 
              onClick={() => handleNavClick('fee-info')}
            >
              <i className="fas fa-money-bill-wave"></i>
              <span>Fee Information</span>
            </li>
            <li 
              className={activeSection === 'entry-slip' ? 'active' : ''} 
              onClick={() => handleNavClick('entry-slip')}
            >
              <i className="fas fa-clipboard-list"></i>
              <span>Entry Slip</span>
            </li>
            <li 
              className={activeSection === 'family-info' ? 'active' : ''} 
              onClick={() => handleNavClick('family-info')}
            >
              <i className="fas fa-users"></i>
              <span>Family Information</span>
            </li>
          </ul>
        </nav>
        <div className="sidebar-footer">
          <button className="btn btn-danger btn-sm">
            <i className="fas fa-trash-alt me-1"></i> Delete
          </button>
        </div>
      </div>
      
      {/* Main Content Area */}
      <div className="main-content">
        {/* Top Action Bar */}
        <div className="top-bar shadow-sm">
          <div className="container-fluid">
            <div className="d-flex align-items-center">
              <button 
                className="btn-action btn-save"
                onClick={saveAll}
                disabled={!Object.values(editingSections).some(Boolean)}
              >
                <i className="fas fa-save me-2"></i>Save
              </button>
              <button className="btn-action btn-verify">
                <i className="fas fa-check-circle me-2"></i>Verify ATP
              </button>
              <button className="btn-action btn-primary">
                <i className="fas fa-save me-2"></i>Save & Close
              </button>
              <button className="btn-action btn-new">
                <i className="fas fa-plus me-2"></i>NEW
              </button>
              <button className="btn-action btn-warning">
                <i className="fas fa-user-slash me-2"></i>Deactivate
              </button>
              <div className="dropdown">
                <button className="btn-action dropdown-toggle" data-bs-toggle="dropdown">
                  <i className="fas fa-ellipsis-h me-2"></i>Actions
                </button>
                <ul className="dropdown-menu">
                  <li><a className="dropdown-item" href="#"><i className="fas fa-print me-2"></i>Print</a></li>
                  <li><a className="dropdown-item" href="#"><i className="fas fa-envelope me-2"></i>Email</a></li>
                  <li><a className="dropdown-item" href="#"><i className="fas fa-history me-2"></i>Audit Log</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        
        {/* Content Sections */}
        <div className="content-sections">
          {/* General Information Section */}
          <section 
            id="general-info" 
            className={`content-section ${activeSection === 'general-info' ? 'active' : ''} ${editingSections['general-info'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-user-circle me-2"></i>General Information</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('general-info')}
              >
                {editingSections['general-info'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['general-info'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('general-info')}
                >
                  Save Section
                </button>
              )}
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label className="field-label">Visitor Reference:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.visitorReference}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.visitorReference}
                    onChange={(e) => handleInputChange('visitorReference', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">CNIC#:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.cnic}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.cnic}
                    onChange={(e) => handleInputChange('cnic', e.target.value)}
                  />
                )}
              </div>
              {/* Continue with all other fields in the same pattern */}
              <div className="form-group">
                <label className="field-label">Email Address:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.email}</div>
                ) : (
                  <input 
                    type="email" 
                    className="field-input form-control" 
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Course:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.course}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.course}
                    onChange={(e) => handleInputChange('course', e.target.value)}
                  />
                )}
              </div>
              {/* Continue with all other fields in the same pattern */}
              <div className="form-group">
                <label className="field-label">Gender:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.gender}</div>
                ) : (
                  <select 
                    className="field-input form-control"
                    value={formData.gender}
                    onChange={(e) => handleInputChange('gender', e.target.value)}
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                )}
              </div>
                <div className="form-group">
                <label className="field-label">Mobile:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.mobile}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.mobile}
                    onChange={(e) => handleInputChange('mobile', e.target.value)}
                  />
                )}
              </div><div className="form-group">
                <label className="field-label">Result Status:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.resultStatus}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.resultStatus}
                    onChange={(e) => handleInputChange('resultStatus', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Challan No:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.challan}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.challan}
                    onChange={(e) => handleInputChange('challan', e.target.value)}
                  />
                )}
              </div><div className="form-group">
                <label className="field-label">UMT Hostel Room:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.hostelRoom}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.hostelRoom}
                    onChange={(e) => handleInputChange('hostelRoom', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">UMT Transport:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.transport}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.transport}
                    onChange={(e) => handleInputChange('transport', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">PWWB:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.pwwb}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.PWWB}
                    onChange={(e) => handleInputChange('PWWB', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Refund:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.refund}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.refund}
                    onChange={(e) => handleInputChange('refund', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Approval Status:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.approvalStatus}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.approvalStatus}
                    onChange={(e) => handleInputChange('approvalStatus', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Learning Support:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.learningSupport}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.learningSupport}
                    onChange={(e) => handleInputChange('learningSupport', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Is any blood related:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.bloodRelated}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.bloodRelated}
                    onChange={(e) => handleInputChange('bloodRelated', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">VPN:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.vpn}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.vpn}
                    onChange={(e) => handleInputChange('vpn', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">DOB:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.dob}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.dob}
                    onChange={(e) => handleInputChange('dob', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Telephone:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.telephone}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.telephone}
                    onChange={(e) => handleInputChange('telephone', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Marital Status:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.meritalStatus}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.meritalStatus}
                    onChange={(e) => handleInputChange('meritalStatus', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Issued Location:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.issuedLocation}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.issuedLocation}
                    onChange={(e) => handleInputChange('issuedLocation', e.target.value)}
                  />
                )}
              </div>
              <div className="form-group">
                <label className="field-label">Alumni:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.alumni}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.alumni}
                    onChange={(e) => handleInputChange('alumni', e.target.value)}
                  />
                )}
              </div>
                   <div className="form-group">
                <label className="field-label">Overseas:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.overseas}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.overseas}
                    onChange={(e) => handleInputChange('overseas', e.target.value)}
                  />
                )}
              </div> 
              <div className="form-group">
                <label className="field-label">Tranferred From:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.transferredFrom}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.transferredFrom}
                    onChange={(e) => handleInputChange('transferredFrom', e.target.value)}
                  />
                )}
              </div> 
              <div className="form-group">
                <label className="field-label">Religion:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.religion}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.religion}
                    onChange={(e) => handleInputChange('religion', e.target.value)}
                  />
                )}
              </div> 
              <div className="form-group">
                <label className="field-label">Nationality:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.nationality}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.nationality}
                    onChange={(e) => handleInputChange('nationality', e.target.value)}
                  />
                )}
              </div> 
              <div className="form-group">
                <label className="field-label">Reference ID:</label>
                {!editingSections['general-info'] ? (
                  <div className="field-value">{formData.referenceId}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.referenceId}
                    onChange={(e) => handleInputChange('referenceId', e.target.value)}
                  />
                )}
              </div> 
           
              {/* Add all other fields in the same pattern */}
            </div>
          </section>

          {/* Program Information Section */}
          <section 
            id="program-info" 
            className={`content-section ${activeSection === 'program-info' ? 'active' : ''} ${editingSections['program-info'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-graduation-cap me-2"></i>Program Information</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('program-info')}
              >
                {editingSections['program-info'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['program-info'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('program-info')}
                >
                  Save Section
                </button>
              )}
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label className="field-label">Campus:</label>
                {!editingSections['program-info'] ? (
                  <div className="field-value">{formData.campus}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.campus}
                    onChange={(e) => handleInputChange('campus', e.target.value)}
                  />
                )}
              </div>
              {/* Add all other program info fields in the same pattern */}
            </div>
          </section>

          {/* Fee Information Section */}
          <section 
            id="fee-info" 
            className={`content-section ${activeSection === 'fee-info' ? 'active' : ''} ${editingSections['fee-info'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-money-bill-wave me-2"></i>Fee Information</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('fee-info')}
              >
                {editingSections['fee-info'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['fee-info'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('fee-info')}
                >
                  Save Section
                </button>
              )}
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label className="field-label">Schedule Type:</label>
                {!editingSections['fee-info'] ? (
                  <div className="field-value">{formData.scheduleType}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.scheduleType}
                    onChange={(e) => handleInputChange('scheduleType', e.target.value)}
                  />
                )}
              </div>
              {/* Add all other fee info fields in the same pattern */}
            </div>
          </section>

          {/* Entry Slip Section */}
          <section 
            id="entry-slip" 
            className={`content-section ${activeSection === 'entry-slip' ? 'active' : ''} ${editingSections['entry-slip'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-clipboard-list me-2"></i>Entry Slip</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('entry-slip')}
              >
                {editingSections['entry-slip'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['entry-slip'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('entry-slip')}
                >
                  Save Section
                </button>
              )}
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label className="field-label">Entry Test Address:</label>
                {!editingSections['entry-slip'] ? (
                  <div className="field-value">{formData.entryTestAddress}</div>
                ) : (
                  <input 
                    type="text" 
                    className="field-input form-control" 
                    value={formData.entryTestAddress}
                    onChange={(e) => handleInputChange('entryTestAddress', e.target.value)}
                  />
                )}
              </div>
              {/* Add all other entry slip fields in the same pattern */}
            </div>
          </section>

          {/* Family Information Section */}
          <section 
            id="family-info" 
            className={`content-section ${activeSection === 'family-info' ? 'active' : ''} ${editingSections['family-info'] ? 'editing' : ''}`}
          >
            <div className="section-header">
              <h4><i className="fas fa-users me-2"></i>Family Information</h4>
              <button 
                className="btn btn-sm btn-outline-primary"
                onClick={() => toggleEdit('family-info')}
              >
                {editingSections['family-info'] ? 'Cancel' : 'Edit'}
              </button>
              {editingSections['family-info'] && (
                <button 
                  className="btn btn-sm btn-primary btn-save-section"
                  onClick={() => saveSection('family-info')}
                >
                  Save Section
                </button>
              )}
            </div>
            <div className="row">
              <div className="col-md-4">
                <div className="family-card">
                  <div className="family-header bg-primary">
                    <h5><i className="fas fa-female me-2"></i>Father</h5>
                  </div>
                  <div className="form-list">
                    <div className="form-group">
                      <label className="field-label">Father Deceased:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherDeceased}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherDeceased}
                          onChange={(e) => handleInputChange('fatherDeceased', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Father Name:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherName}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherName}
                          onChange={(e) => handleInputChange('fatherName', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Father CNIC:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherCnic}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherCnic}
                          onChange={(e) => handleInputChange('fatherCnic', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Father Address:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherAddress}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherAddress}
                          onChange={(e) => handleInputChange('fatherAddress', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Father Mobile:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherMobile}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherMobile}
                          onChange={(e) => handleInputChange('fatherMobile', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Father Designation:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherDesignation}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherDesignation}
                          onChange={(e) => handleInputChange('fatherDesignation', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Father Organization:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherOrganization}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherOrganization}
                          onChange={(e) => handleInputChange('fatherOrganization', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Father Organization:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherDeceased}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherDeceased}
                          onChange={(e) => handleInputChange('fatherDeceased', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Organization Number:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.fatherOrganizationNumber}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.fatherOrganizationNumber}
                          onChange={(e) => handleInputChange('fatherOrganizationNumber', e.target.value)}
                        />
                      )}
                    </div>
                    {/* Add all other father fields in the same pattern */}
                  </div>
                </div>
              </div>
              {/* Add mother and guardian sections in the same pattern */}
              <div className="col-md-4">
                <div className="family-card">
                  <div className="family-header bg-danger">
                    <h5><i className="fas fa-male me-2"></i>Mother</h5>
                  </div>
                  <div className="form-list">
                    <div className="form-group">
                      <label className="field-label">Mother Deceased:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherDeceased}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherDeceased}
                          onChange={(e) => handleInputChange('motherDeceased', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Mother Name:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherName}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherName}
                          onChange={(e) => handleInputChange('motherName', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Mother CNIC:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherCnic}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherCnic}
                          onChange={(e) => handleInputChange('motherCnic', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Mother Address:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherAddress}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherAddress}
                          onChange={(e) => handleInputChange('motherAddress', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Mother Mobile:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherMobile}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherMobile}
                          onChange={(e) => handleInputChange('motherMobile', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Mother Designation:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherDesignation}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherDesignation}
                          onChange={(e) => handleInputChange('motherDesignation', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Mother Organization:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherOrganization}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherOrganization}
                          onChange={(e) => handleInputChange('motherOrganization', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Organization Address:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherOrganizationAddress}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherOrganizationAddress}
                          onChange={(e) => handleInputChange('motherOrganizationAddress', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Organization Number:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.motherOrganizationNumber}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.motherOrganizationNumber}
                          onChange={(e) => handleInputChange('motherOrganizationNumber', e.target.value)}
                        />
                      )}
                    </div>
                    {/* Add all other father fields in the same pattern */}
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="family-card">
                  <div className="family-header bg-success">
                    <h5><i className="fas fa-male me-2"></i>Gaurdian</h5>
                  </div>
                  <div className="form-list">
                    <div className="form-group">
                      <label className="field-label">Gaurdian Deceased:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdianDeceased}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdianDeceased}
                          onChange={(e) => handleInputChange('gaurdianDeceased', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Gaurdian Name:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdiabnName}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdiabnName}
                          onChange={(e) => handleInputChange('gaurdiabnName', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Gaurdian CNIC:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdianCnic}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdianCnic}
                          onChange={(e) => handleInputChange('gaurdianCnic', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Gaurdian Address:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdianAddress}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdianAddress}
                          onChange={(e) => handleInputChange('gaurdianAddress', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Gaurdian Mobile:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdianMobile}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdianMobile}
                          onChange={(e) => handleInputChange('gaurdianMobile', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Gaurdian Designation:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdianDesignation}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdianDesignation}
                          onChange={(e) => handleInputChange('gaurdianDesignation', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Gaurdian Organization:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdianOrganization}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdianOrganization}
                          onChange={(e) => handleInputChange('gaurdianOrganization', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Organization Address:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdianOrganizationAddress}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdianOrganizationAddress}
                          onChange={(e) => handleInputChange('gaurdianOrganizationAddress', e.target.value)}
                        />
                      )}
                    </div>
                    <div className="form-group">
                      <label className="field-label">Organization Number:</label>
                      {!editingSections['family-info'] ? (
                        <div className="field-value">{formData.gaurdianOrganizationNumber}</div>
                      ) : (
                        <input 
                          type="text" 
                          className="field-input form-control" 
                          value={formData.gaurdianOrganizationNumber}
                          onChange={(e) => handleInputChange('gaurdianOrganizationNumber', e.target.value)}
                        />
                      )}
                    </div>
                    {/* Add all other father fields in the same pattern */}
                  </div>
                </div>
              </div>
            </div>
            
          </section>
        </div>
      </div>
    </div>
  );
};

export default StudentDetails; 