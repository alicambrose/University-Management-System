import React, { useState } from 'react';
import { useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faPlus, 
  faTrashAlt,
  faChartBar,
  faFileExport,
  faFileAlt,
  faChevronDown,
  faSort,
  faSortUp,
  faSortDown
} from '@fortawesome/free-solid-svg-icons';
import './StudentCourses.css';
import TopNavBar from '../TopNavBar';

const StudentCourse = () => {
  const [activeForm, setActiveForm] = useState(null);
  const [courseCode] = useState('MA050-F2024065-F2024065005-F2024');
  const [showFormsDropdown, setShowFormsDropdown] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
      useEffect(() => {
    const handleClickOutside = (e) => {
      if (!e.target.closest('.mobile-forms-dropdown')) {
        setShowFormsDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  const forms = [
    { id: 'assessment', name: 'Course Assessment' },
    { id: 'details', name: 'Course Details' },
    { id: 'associations', name: 'Course Associations' }
  ];

  // Sample assessment data
  const assessmentData = [
    {
      studentCourse: 'CS101-2023',
      student: 'Abdul Rehman',
      assessmentName: 'Midterm Exam',
      assessmentType: 'Exam',
      weightage: 30,
      totalMarks: 100,
      marksObtained: 85,
      weightageObtained: 25.5,
      createdOn: '2023-10-15'
    },
    {
      studentCourse: 'CS101-2023',
      student: 'Ali Khan',
      assessmentName: 'Midterm Exam',
      assessmentType: 'Exam',
      weightage: 30,
      totalMarks: 100,
      marksObtained: 72,
      weightageObtained: 21.6,
      createdOn: '2023-10-15'
    },
    {
      studentCourse: 'CS101-2023',
      student: 'Sara Ahmed',
      assessmentName: 'Assignment 1',
      assessmentType: 'Assignment',
      weightage: 10,
      totalMarks: 50,
      marksObtained: 45,
      weightageObtained: 9,
      createdOn: '2023-09-20'
    },
    {
      studentCourse: 'CS101-2023',
      student: 'Usman Malik',
      assessmentName: 'Quiz 1',
      assessmentType: 'Quiz',
      weightage: 5,
      totalMarks: 20,
      marksObtained: 18,
      weightageObtained: 4.5,
      createdOn: '2023-09-10'
    },
    {
      studentCourse: 'CS101-2023',
      student: 'Fatima Khan',
      assessmentName: 'Final Exam',
      assessmentType: 'Exam',
      weightage: 40,
      totalMarks: 100,
      marksObtained: 92,
      weightageObtained: 36.8,
      createdOn: '2023-12-05'
    }
  ];

  // Sorting functionality
  const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return faSort;
    return sortConfig.direction === 'asc' ? faSortUp : faSortDown;
  };

  const sortedData = [...assessmentData];
  if (sortConfig.key) {
    sortedData.sort((a, b) => {
      if (a[sortConfig.key] < b[sortConfig.key]) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (a[sortConfig.key] > b[sortConfig.key]) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  }

  return (
    <div className="mobile-app-container">
      <TopNavBar />
      
      {/* Course Header */}
      <div className="mobile-course-header">
        <h2>STUDENT COURSE</h2>
        <p className="course-code">{courseCode}</p>
      </div>

      {/* Forms Dropdown - Mobile Version */}
      <div className="mobile-forms-dropdown">
<button 
  className="mobile-dropdown-toggle"
  onClick={(e) => {
    e.stopPropagation(); // Prevent event bubbling
    setShowFormsDropdown(!showFormsDropdown);
  }}
>
  <FontAwesomeIcon icon={faFileAlt} className="me-2" />
  Course Assessment Details Associate
  <FontAwesomeIcon 
    icon={faChevronDown} 
    className={`dropdown-chevron ${showFormsDropdown ? 'open' : ''}`}
  />
</button>
        
        {showFormsDropdown && (
          <div className="mobile-dropdown-menu">
            {forms.map(form => (
              <button 
                key={form.id}
                className="mobile-dropdown-item"
                onClick={() => {
                  setActiveForm(form.id);
                  setShowFormsDropdown(false);
                }}
              >
                {form.name}
              </button>
            ))}
          </div>
        )}
      </div>
      
      {/* Action Buttons - Mobile Version */}
      <div className="mobile-action-buttons">
        <button className="mobile-action-btn primary">
          <FontAwesomeIcon icon={faPlus} />
          <span>ADD NEW</span>
        </button>
        <button className="mobile-action-btn danger">
          <FontAwesomeIcon icon={faTrashAlt} />
          <span>DELETE</span>
        </button>
        <button className="mobile-action-btn info">
          <FontAwesomeIcon icon={faChartBar} />
          <span>CHART</span>
        </button>
        <button className="mobile-action-btn warning">
          <FontAwesomeIcon icon={faFileAlt} />
          <span>REPORT</span>
        </button>
        <button className="mobile-action-btn success">
          <FontAwesomeIcon icon={faFileExport} />
          <span>EXPORT</span>
        </button>
      </div>

      {/* Content Section */}
      <div className="mobile-content-section">
        {/* Assessment Content */}
        <div className="assessment-section">
          <h3>Course Assessment Details</h3>

          {/* Assessment Table */}
          <div className="assessment-table-container">
            <table className="assessment-table">
              <thead>
                <tr>
                  <th onClick={() => requestSort('studentCourse')}>
                    Student Course
                    <FontAwesomeIcon 
                      icon={getSortIcon('studentCourse')} 
                      className="sort-icon"
                    />
                  </th>
                  <th onClick={() => requestSort('student')}>
                    Student
                    <FontAwesomeIcon 
                      icon={getSortIcon('student')} 
                      className="sort-icon"
                    />
                  </th>
                  <th onClick={() => requestSort('assessmentName')}>
                    Assessment Name
                    <FontAwesomeIcon 
                      icon={getSortIcon('assessmentName')} 
                      className="sort-icon"
                    />
                  </th>
                  <th onClick={() => requestSort('assessmentType')}>
                    Assessment Type
                    <FontAwesomeIcon 
                      icon={getSortIcon('assessmentType')} 
                      className="sort-icon"
                    />
                  </th>
                  <th onClick={() => requestSort('weightage')}>
                    Weightage (%)
                    <FontAwesomeIcon 
                      icon={getSortIcon('weightage')} 
                      className="sort-icon"
                    />
                  </th>
                  <th onClick={() => requestSort('totalMarks')}>
                    Total Marks
                    <FontAwesomeIcon 
                      icon={getSortIcon('totalMarks')} 
                      className="sort-icon"
                    />
                  </th>
                  <th onClick={() => requestSort('marksObtained')}>
                    Marks Obtained
                    <FontAwesomeIcon 
                      icon={getSortIcon('marksObtained')} 
                      className="sort-icon"
                    />
                  </th>
                  <th onClick={() => requestSort('weightageObtained')}>
                    Weightage Obtained
                    <FontAwesomeIcon 
                      icon={getSortIcon('weightageObtained')} 
                      className="sort-icon"
                    />
                  </th>
                  <th onClick={() => requestSort('createdOn')}>
                    Created On
                    <FontAwesomeIcon 
                      icon={getSortIcon('createdOn')} 
                      className="sort-icon"
                    />
                  </th>
                </tr>
              </thead>
              <tbody>
                {sortedData.map((assessment, index) => (
                  <tr key={index}>
                    <td>{assessment.studentCourse}</td>
                    <td>{assessment.student}</td>
                    <td>{assessment.assessmentName}</td>
                    <td>{assessment.assessmentType}</td>
                    <td>{assessment.weightage}</td>
                    <td>{assessment.totalMarks}</td>
                    <td>{assessment.marksObtained}</td>
                    <td>{assessment.weightageObtained.toFixed(1)}</td>
                    <td>{new Date(assessment.createdOn).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentCourse;