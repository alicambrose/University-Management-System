import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { faUserGraduate, faLock, faSignInAlt, faSpinner } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './Login.css';

const Login = () => {
  const navigate = useNavigate(); 
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    studentId: '',
    password: '',
    remember: false
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate authentication
    setTimeout(() => {
      setIsLoading(false);
      // You would typically handle navigation here
      // navigate('/dashboard');
      navigate('/student-details');
    }, 1500);
  };

  return (
    <div className="login-page"> 
    <div className="login-container floating">
      <div className="logo">
        <img 
          src="https://upload.wikimedia.org/wikipedia/commons/c/c8/Umt_logo.png" 
          alt="University Logo" 
          className="floating" 
          style={{ animationDuration: '5s' }}
        />
        <h1>University Portal</h1>
        <p>Student Management System</p>
      </div>
      
      <form onSubmit={handleSubmit}>
       <div className="login-form-group">
  <label htmlFor="studentId">Student ID</label>
  <div className="input-wrapper">
    <FontAwesomeIcon icon={faUserGraduate} className="input-icon" />
    <input
      type="text"
      id="studentId"
      name="studentId"
      className="login-form-control"
      placeholder="Enter your student ID"
      required
      aria-label="Student ID"
      value={formData.studentId}
      onChange={handleChange}
    />
  </div>
</div>

<div className="login-form-group">
  <label htmlFor="password">Password</label>
  <div className="input-wrapper">
    <FontAwesomeIcon icon={faLock} className="input-icon" />
    <input
      type="password"
      id="password"
      name="password"
      className="login-form-control"
      placeholder="Enter your password"
      required
      value={formData.password}
      onChange={handleChange}
    />
  </div>
</div>
        
        <div className="remember-forgot">
          <div className="remember-me">
            <input
              type="checkbox"
              id="remember"
              name="remember"
              checked={formData.remember}
              onChange={handleChange}
            />
            <label htmlFor="remember">Remember me</label>
          </div>
          <div className="forgot-password">
            <a href="#">Forgot password?</a>
          </div>
        </div>
        
        <button type="submit" className="btn-login" disabled={isLoading}>
          {isLoading ? (
            <FontAwesomeIcon icon={faSpinner} spin />
          ) : (
            <>
              <FontAwesomeIcon icon={faSignInAlt} /> Login
            </>
          )}
        </button>
      </form>
      
      <div className="login-footer">
        <p>Don't have an account? <a href="#">Contact administration</a></p>
        <p>&copy; {new Date().getFullYear()} University Management System</p>
      </div>
    </div>
    </div>
  );
};

export default Login;