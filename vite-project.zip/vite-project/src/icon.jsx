// src/icons.js
import React from 'react';
import { library } from '@fortawesome/fontawesome-svg-core';
import { 
  faUserCircle, 
  faGraduationCap,
  faMoneyBillWave,
  faClipboardList,
  faUsers,
  faCamera,
  faUpload,
  faTrashAlt,
  faSave,
  faCheckCircle,
  faPlus,
  faUserSlash,
  faEllipsisH,
  faPrint,
  faEnvelope,
  faHistory
} from '@fortawesome/free-solid-svg-icons';

library.add(
  faUserCircle,
  faGraduationCap,
  faMoneyBillWave,
  faClipboardList,
  faUsers,
  faCamera,
  faUpload,
  faTrashAlt,
  faSave,
  faCheckCircle,
  faPlus,
  faUserSlash,
  faEllipsisH,
  faPrint,
  faEnvelope,
  faHistory
);
export default icon;