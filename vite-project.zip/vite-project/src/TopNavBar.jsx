import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faHome, 
  faSearch,
  faUserGraduate,
  faUserTie,
  faQuestionCircle,
  faBook,
  faFileAlt,
  faChartLine,
  faClipboardList,
  faUsers,
  faCalendarAlt,
  faEnvelope,
  faMoneyBillWave,
  faGraduationCap,
  faUniversity,
  faIdCard,
  faTasks,
  faFileInvoice,
  faCertificate,
  faChartPie,
  faChartColumn,
  faChartArea,
  faChartSimple,
  faGauge,
  faGaugeHigh,
  faGaugeSimple,
  faGaugeSimpleHigh,
  faChartGantt
} from '@fortawesome/free-solid-svg-icons';

import { Link } from 'react-router-dom';
import './TopNavBar.css';

const TopNavBar = () => {
  const [activeDropdown, setActiveDropdown] = useState(null);

  const toggleDropdown = (dropdownName) => {
    setActiveDropdown(activeDropdown === dropdownName ? null : dropdownName);
  };

  // Admission forms data with icons and colors
  const admissionForms = [
    { id: 'student-details', name: 'Student Details', icon: faUserGraduate, color: '#4361ee' },
    { id: 'visitor-details', name: 'Visitor Profile', icon: faUserTie, color: '#4895ef' },
    { id: 'student-inquiries', name: 'Student Inquiries', icon: faQuestionCircle, color: '#f72585' },
    { id: 'student-courses', name: 'Student Courses', icon: faBook, color: '#4cc9f0' },
    { id: 'applications', name: 'Applications', icon: faFileAlt, color: '#3f37c9' },
    { id: 'admissions', name: 'Admissions', icon: faGraduationCap, color: '#b5179e' },
    { id: 'registrations', name: 'Registrations', icon: faClipboardList, color: '#f77f00' },
    { id: 'batch-management', name: 'Batch Management', icon: faUsers, color: '#7209b7' },
    { id: 'scheduling', name: 'Scheduling', icon: faCalendarAlt, color: '#3a86ff' },
    { id: 'communications', name: 'Communications', icon: faEnvelope, color: '#ff006e' },
    { id: 'fee-management', name: 'Fee Management', icon: faMoneyBillWave, color: '#8338ec' },
    { id: 'programs', name: 'Programs', icon: faUniversity, color: '#ffbe0b' },
    { id: 'student-id', name: 'Student ID', icon: faIdCard, color: '#fb5607' },
    { id: 'tasks', name: 'Tasks', icon: faTasks, color: '#3a0ca3' },
    { id: 'reports', name: 'Reports', icon: faChartLine, color: '#f15bb5' },
    { id: 'transcripts', name: 'Transcripts', icon: faFileInvoice, color: '#9b5de5' },
    { id: 'certificates', name: 'Certificates', icon: faCertificate, color: '#00bbf9' },
    { id: 'attendance', name: 'Attendance', icon: faClipboardList, color: '#00f5d4' },
    { id: 'evaluations', name: 'Evaluations', icon: faFileAlt, color: '#fee440' }
  ];
const dashboardForms = [
  { id: 'main-dashboard', name: 'Main Dashboard', icon: faGauge, color: '#3a86ff' },
  { id: 'performance', name: 'Performance', icon: faChartPie, color: '#8338ec' },
  // ... rest of your dashboardForms array
];
  return (
    <nav className="top-navbar">
      <div className="navbar-left">
        {/* Microsoft Dynamics CRM Dropdown */}
        <div className={`dropdown ${activeDropdown === 'crm' ? 'show' : ''}`}>
          <button 
            className="nav-btn dropdown-toggle" 
            onClick={() => toggleDropdown('crm')}
          >
            Microsoft Dynamics CRM
          </button>
          <ul className="dropdown-menu">
            <li><Link className="dropdown-item" to="/">Option 1</Link></li>
            <li><Link className="dropdown-item" to="/">Option 2</Link></li>
          </ul>
        </div>

        {/* Home Button */}
        <Link to="/home" className="nav-btn">
          <FontAwesomeIcon icon={faHome} className="me-2" />
          HOME
        </Link>

        {/* ADMISSION Dropdown */}
        <div className={`dropdown ${activeDropdown === 'admission' ? 'show' : ''}`}>
          <button 
            className="nav-btn dropdown-toggle"
            onClick={() => toggleDropdown('admission')}
          >
            ADMISSION
          </button>
          {activeDropdown === 'admission' && (
            <div className="forms-tile-container">
              {admissionForms.map((form) => (
                 // In TopNavBar.jsx, modify the form-tile Link component:
<Link 
  key={form.id}
  to={`/${form.id}`}
  className="form-tile"
  style={{ backgroundColor: form.color }}
  onClick={() => setActiveDropdown(null)} // Add this line
>
  <FontAwesomeIcon icon={form.icon} className="form-icon" />
  <span className="form-name">{form.name}</span>
</Link>
              ))}
            </div>
          )}
        </div>
        {/* Dashboard Dropdown */}
        <div className={`dropdown ${activeDropdown === 'dashboard' ? 'show' : ''}`}>
              <button 
                className="nav-btn dropdown-toggle"
               onClick={() => toggleDropdown('dashboard')}
             >
            DASHBAORD
          </button>
            {activeDropdown === 'dashboard' && (
    <div className="forms-tile-container">
      {dashboardForms.map((form) => (
        <Link 
          key={form.id}
          to={`/${form.id}`}
          className="form-tile"
          style={{ backgroundColor: form.color }}
          onClick={() => setActiveDropdown(null)}
        >
          <FontAwesomeIcon icon={form.icon} className="form-icon" />
          <span className="form-name">{form.name}</span>
        </Link>
      ))}
    </div>
  )}
         </div>
      </div>
      {/* Search Bar */}
      <div className="search-bar">
        <div className="input-group">
          <input 
            type="text" 
            className="form-control" 
            placeholder="Enter Search Item" 
          />
          <button className="btn btn-search" type="button">
            <FontAwesomeIcon icon={faSearch} />
          </button>
        </div>
      </div>
    </nav>
  );
};
export default TopNavBar;